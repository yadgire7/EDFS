
const socket = new WebSocket("ws://localhost:6060");
const formElem = document.querySelector('form');

var term = new window.Terminal({
    cursorBlink: true
});
term.open(document.getElementById('terminal'));

formElem.addEventListener('submit', (e) => {
    // on form submission, prevent default
    e.preventDefault();

    // construct a FormData object, which fires the formdata event
    new FormData(formElem);
});
formElem.addEventListener('formdata', (e) => {
    // Get the form data from the event object
    const data = e.formData;
    var param = Array.from(data.values());
    param = '*' + param
    socket.send(param);

});
// create table for partitions
function createTable(data) {
    var table = document.getElementById('analytics')
    var toWrite = '';
    data.pop();
    data.forEach((d, i) => {
        var feature = d.find(i => i != '');
        var analytics = d.slice(-1)[0];
        // title
        if (i == 0) {
            toWrite = `<h3>${feature} ${analytics}</h3>`
        }
        // header
        else if (i == 1) {
            toWrite += ` <table class="table table-bordered table-sm  table-hover">
            <thead>
              <tr>
              <th scope="col">${feature}</th>
              <th scope="col">${analytics}</th>
              </tr>
            </thead>`
        } 
        else {
            toWrite += `<tr>
                        <td>
                        ${feature}
                        </td>
                        <td>
                        ${analytics}
                        </td>
                        </tr>`;

        }
    });
    table.innerHTML += toWrite
    return
}
// create table for analytics and partition
function writeResult(data) {
    var char = '\n';
    var i = j = 0;
    toWrite = '';
    isPartition = false
    partitionList = []

    var header = document.getElementById('header');
    j = data.indexOf(char, i)
    header.innerHTML = `<th scope="col">${data.substring(j + 1, data.indexOf(char, j + 1))}</th>
                        <th scope="col">${data.substring(i, j)}</th>`;

    var tbody = document.getElementById('body');
    i = data.indexOf(char, j + 2) + 1;

    while ((j = data.indexOf(char, i)) !== -1) {
        temp = data.substring(i, j).split(' ')
        // check if data received is a partition
        if (temp.length == 2) {
            isPartition = true

        }
        if (isPartition) {
            partitionList.push(temp)

        }
        // check that end of a partition thus have to create a table
        if (temp.length == 3) {
            isPartition = false
            createTable(partitionList)
            partitionList = []
        }
        // not a partition
        if (!isPartition) {
            feature = temp[0]
            analytics = temp.slice(-1)[0]
            if (feature != 'end') {
                toWrite += `<tr>
                <td>
                ${feature}
                </td>
                <td>
                ${analytics}
                </td>

            </tr>`;
            }
        }
        tbody.innerHTML = toWrite;
        i = j + 1;

    }

}

// initialize terminal
function init() {
    if (term._initialized) {
        return;
    }

    term._initialized = true;

    term.prompt = () => {
        term.write('\r\n$ ');
    };
    prompt(term);

    term.onData(e => {
        switch (e) {
            case '\u0003': // Ctrl+C
                term.write('^C');
                prompt(term);
                break;
            case '\r': // Enter
                runCommand(term, command);
                command = '';
                break;
            case '\u007F': // Backspace (DEL)
                // Do not delete the prompt
                if (term._core.buffer.x > 2) {
                    term.write('\b \b');
                    if (command.length > 0) {
                        command = command.substr(0, command.length - 1);
                    }
                }
                break;
            case '\u0009':
                console.log('tabbed', output, ["dd", "ls"]);
                break;
            default:
                if (e >= String.fromCharCode(0x20) && e <= String.fromCharCode(0x7E) || e >= '\u00a0') {
                    command += e;
                    term.write(e);
                }
        }
    });
}

function clearInput(command) {
    var inputLengh = command.length;
    for (var i = 0; i < inputLengh; i++) {
        term.write('\b \b');
    }
}
function prompt(term) {
    command = '';
    term.write('\r\n$ ');
}
socket.onmessage = (event) => {
    // check if data is for analytics else terminal
    if (event.data[0] == '*') {
        writeResult(event.data.slice(1));
    } else {
        term.write('\r\n')
        term.write(event.data);
        term.write('$ ');
    }

}

function runCommand(term, command) {
    if (command.length > 0) {
        //clearInput(command);
        socket.send(command);
        return;
    }
}

init();
