import os
import sys


import firebase_admin
from firebase_admin import credentials, db, storage

cred = credentials.Certificate(
    "py2fb\dsci551-project-627ea-firebase-adminsdk-e1lvi-2055f80a76.json")
# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://dsci551-project-627ea-default-rtdb.firebaseio.com/',
    'storageBucket': 'dsci551-project-627ea.appspot.com'
})

ref = db.reference("/")


def main():
    command = sys.argv[1]
    input = sys.argv[2:]

    if command == 'mkdir':
        mkdir(input[0])
    elif command == 'ls':
        ls(input[0])
    elif command == 'cat':
        os.remove(cat(input[0]))
    elif command == 'rm':
        rm(input[0])
    elif command == 'put':
        files = put(input[0], input[1], int(input[2]))
        for file in files[1:]:
            file.close()
            os.remove(file.name)

    elif command == 'getPartitionLocations':
        getPartitionLocations(input[0])
    elif command == 'readPartition':
        os.remove(readPartition(input[0], input[1]))

# convert the file path into a nested dictionary


def createJSON(path, dictionary):
    while path.startswith('/'):
        path = path[1:]
    parts = path.split('/', 1)
    if len(parts) > 1:
        branch = dictionary.setdefault(parts[0], {})
        createJSON(parts[1], branch)
    else:
        # need empty string else can't upload to firebase
        dictionary[parts[0]] = ''
    return dictionary

# get all possible paths


def get_all_paths(d, path, paths):
    for key, value in d.items():
        temp = path + '/' + key
        if value == '':
            paths.append(temp)
        if isinstance(value, dict):
            get_all_paths(value, temp, paths)

    return paths


def mkdir(path):
    # get all the files that exist in the database
    curr_files = ref.get('/')

    output = {}  # dict to be uploaded containing the file system hierarchy
    paths = []

    # check that there is content in the database
    if curr_files[0] is not None:
        # convert the JSON to strings of filepath
        get_all_paths(curr_files[0], '', paths)

    path = '/root' + path

    # append newest path
    paths.append(path)

    for p in paths:
        createJSON(p, output)

    ref.set(output)
    return


def ls(file_path):
    if file_path == "/":
        ref = db.reference("/root")
        # print(ref)
        data = ref.get()
        # print(data)
        for k, v in data.items():
            print(k)
    else:
        file_path = "/root"+file_path
        # print(file_path)
        ref = db.reference(file_path)
        # print(ref)
        data = ref.get()
        if data == "" or data is None:
            print("Empty directory!")
        else:
            # print(data)
            for k, v in data.items():
                print(k)
    return


def cat(file):
    bucket = storage.bucket(firebase_admin.storage.bucket().name)
    file, extentsion = file.split('.')
    temp_file = file.split('/')[-1]

    # format the file to include the extension
    file = f'{file}.{extentsion}'

    # download file
    blob = bucket.blob(file)
    temp_file = f'temp_{temp_file}'
    blob.download_to_filename(temp_file)


    # save content of file into string then remove the temp file
    with open(temp_file) as f:
        res = f.read()

    print(res)
    return temp_file


def rm(file):
    file_path = "/root" + file
    fname, extention = file.split('.')
    bucket = storage.bucket()
    folder = file_path.split('/')[-1].split('.')[0]
    file_path = '/'.join(file_path.split('/')[:-1])
    ref = db.reference(file_path)
    res = ref.get()
    partitions = res[folder]["partitions"]
    
    blob = bucket.blob(file)
    try:
        
        blob.delete()
        for i in range(partitions):
            blob = bucket.blob(f'{fname}{i+1}.{extention}')
            blob.delete()
        ref.child(folder).set({})
        print(f'Successfully deleted {file}')
        mkdir(file_path[5:])
    except:
        print('rm: cannot remove \''+str(file)+'\': No such file')
        return


def put(file, path, partitions):
    # just in case the file includes the path
    base_file = file.split('/')[-1]
    fname, extension = base_file.split('.')
    urls = []
    output = {}

    with open(file) as f:
        files_to_write = []
        if partitions > 1:
            # create k files based on partitions
            files_to_write = [open(f'{fname}{i+1}.{extension}', 'w+')
                              for i in range(partitions)]
            # write data to each partitioned file
            for i, line in enumerate(f):
                files_to_write[i % partitions].write(line)

        # insert original file
        files_to_write.insert(0, f)

        # upload the files into Cloud Storage
        for f in files_to_write:
            f.mode = 'r+'
            bucket = storage.bucket()
            if '/' in f.name:
                blob = bucket.blob(f'{path}/{f.name[f.name.find("/") + 1:]}')
            else: 
                blob = bucket.blob(f'{path}/{f.name}')
            blob.upload_from_filename(f.name)
            blob.make_public()
            urls.append(blob.public_url)

    path = '/root' + path
    '''
    folder is the last subdirectory in the given path
    eg: /user/john
    folder = john
    path = /user

    we need to do this because of how we get data from firebase
    '''
    folder = path.split('/')[-1]
    # this removes folder from the given path
    path = '/'.join(path.split('/')[:-1])

    ref = db.reference(path)

    # we separate the file from the extension because firebase does not accept keys that include .
    output["extension"] = extension

    # add partition too for rm
    output["partitions"] = partitions

    # format object to include partition and location
    output["base"] = urls[0]
    for i, url in enumerate(urls[1:]):
        output[f"p{i+1}"] = url

    # update the data to firebase
    ref.child(folder).update({fname: output})
    print("Files Uploaded")
    return files_to_write


def getPartitionLocations(file):
    fname, extension = file.split('.')

    ref = db.reference('/root' + fname)
    res = ref.get()

    if res is not None and res['extension'] == extension:
        # skip the extension key in the dict
        items = iter(res.items())
        next(items)
        next(items)
        for k, v in items:
            print(v)
    else:
        print(f'{file} does not exist')

    return


def readPartition(file, partition_number):
    bucket = storage.bucket(firebase_admin.storage.bucket().name)
    file, extentsion = file.split('.')
    temp_file = file.split('/')[-1]

    # format the file to include the partition number
    file = f'{file}{partition_number}.{extentsion}'

    # download file
    blob = bucket.blob(file)
    temp_file = f'temp_{temp_file}'
    blob.download_to_filename(temp_file)

    # save content of file into string then remove the temp file
    with open(temp_file) as f:
        res = f.read()

    print(res)
    return temp_file


if __name__ == '__main__':
    main()
