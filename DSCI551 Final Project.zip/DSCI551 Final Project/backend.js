const WebSocket = require('ws')
var os = require('os');

const { spawn } = require('child_process');

const wss = new WebSocket.Server({ port: 6060 })

console.log("Socket is up and running...")

wss.on('connection', ws => {
    console.log("new session")
    ws.on('message', command => {
        commands = command.toString();
        // check if command is for analytics
        if (commands[0] == '*') {
            // remove *
            commands = commands.slice(1);
            commands = commands.split(",");
            var from = commands[0]
            var partitions = commands[1]
            var analytics_option = commands[2]
            var analytics_feature = commands[3]
            var select = []
            let index = 4
            for (let i = 4; i < commands.length; i++) {
                if (commands[i] == "Single" || commands[i] == "Range") {
                    index = i;
                    break;
                } else {
                    select.push(commands[i])
                }
            }
            var search = commands[index]
            var search_id = commands[index + 1]
            var single_condition = commands[index + 2]
            var single_condition_value = commands[index + 3]
            var range_lower = commands[index + 4]
            var range_lower_operator = commands[index + 5]
            var range_higher = commands[index + 6]
            var range_higher_operator = commands[index + 7]

            /*
            console.log(from)
            console.log(analytics_option)
            console.log(analytics_feature)
            console.log(select)
            console.log(search)
            console.log(search_id)
            console.log(single_condition)
            console.log(single_condition_value)
            console.log(range_lower)
            console.log(range_lower_operator)
            console.log(range_higher)
            console.log(range_higher_operator)
            */

            params = ['project-part-2.py', from, partitions, analytics_option, analytics_feature, select, search, search_id, single_condition,
                single_condition_value, range_lower, range_lower_operator, range_higher, range_higher_operator]
            var dataToSend;
            // spawn new child process to call the python script
            const python = spawn('python', params);
            // collect data from script
            python.stdout.on('data', function (data) {
                console.log('Pipe data from python script ...');
                dataToSend = '*' + data.toString();
            })
            python.stderr.pipe(process.stderr);
            python.on('close', (code) => {
                console.log(dataToSend)
                console.log(`child process close all stdio with code ${code}`);
                // send data to browser
                if (code == 0) {
                    ws.send(dataToSend)
                }

            });

        }
        // command is for terminal
        else {
            commands = commands.split(" ");

            commands = ['python', 'py2fb/py2fb.py', ...commands]
            params = commands.join(' ')
            var dataToSend;

            var python = require('child_process').exec;
            python(params, function(error, stdout, stderr) {
                ws.send(stdout)
            })

        }


    })

})