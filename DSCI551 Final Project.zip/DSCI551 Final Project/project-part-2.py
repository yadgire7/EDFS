import pandas as pd
import numpy as np
import sys


import firebase_admin
from firebase_admin import credentials, db, storage

cred = credentials.Certificate(
    "py2fb\dsci551-project-627ea-firebase-adminsdk-e1lvi-2055f80a76.json")
# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://dsci551-project-627ea-default-rtdb.firebaseio.com/',
    'storageBucket': 'dsci551-project-627ea.appspot.com'
})

def main():
  
    
    parts = []
    for file in filenames:
        parts.append(mapPartition(file))
    data = Reduce(parts)
    
    print(data)
    
    for i, part in enumerate(parts):
        print('Partition '+str(i+1)+':')
        print(part.to_string(index=False))
        print('end of partition')
    
    return


def mapPartition(p):
    global select
    if groupby != None and atp == 'Count':
        select = [groupby]
    elif groupby != None:
        select.append(groupby)
    if where == None:
        p = p
    elif where == 'Range':
        p = rangeCondition(p)
    else:
        p = singleCondition(p)
    if 'All' in select:
        df = p
    else:
        df = p[select]
    df = df.loc[:,~df.columns.duplicated()].copy()
    if groupby != None:
        df = analyze(df)
    return df

def Reduce(*parts):
    df = pd.concat(parts[0],axis=0)
    if groupby:
        if atp == 'Count':
            df = df.groupby(groupby).sum()
        if atp == 'Average':
            df = df.groupby(groupby).mean()
        if atp == 'Max':
            df = df.groupby(groupby).max()
        if atp == 'Min':
            df = df.groupby(groupby).min()
    return df

# if single condition was chosen
def singleCondition(df):
    
    if single_cd == '=':
        df = df.loc[df[feat] == single_val]
    elif single_cd == '<':
        df = df.loc[df[feat] < single_val]
    elif single_cd == '>':
        df = df.loc[df[feat] > single_val]
    elif single_cd == '≤':
        df = df.loc[df[feat] <= single_val]
    elif single_cd == '≥':
        df = df.loc[df[feat] >= single_val]
    return df

#if range of values was chosen
def rangeCondition(df):
    if lo_cd == '≤'and hi_cd == '≤':
        ids = (df[feat] >= lo_val) & (hi_val >= df[feat])
    if lo_cd == '≤' and hi_cd != '≤':
        ids = (df[feat] >= lo_val) & (hi_val > df[feat])
    if lo_cd != '≤' and hi_cd == '≤':
        ids = (df[feat] > lo_val) & (hi_val >= df[feat])
    else:
        ids = (df[feat] > lo_val) & (hi_val > df[feat])
        
    return df.loc[ids]

#if groupby
def analyze(df):
    if atp == 'Count':
        df = df.groupby([groupby]).size().reset_index(name='Count')
    elif atp == 'Average':
        df = df.groupby([groupby]).mean().reset_index()
    elif atp == 'Max':
        df.groupby(groupby).max().reset_index()
    elif atp == 'Min':
        df.groupby(groupby).min().reset_index()
    return df

def downloadPartitions(file, partitions):
    bucket = storage.bucket(firebase_admin.storage.bucket().name)
    file, extentsion = file.split('.')
    file = '/flipkart/' + file
    

    files_list = []
    filenames = []

    # download all partitions
    for i in range(partitions):
        file_partition = f'{file}{i+1}.{extentsion}'
        temp_file = file_partition.split('/')[-1]
        blob = bucket.blob(file_partition)
        temp_file = f'temp_{temp_file}'
        blob.download_to_filename(temp_file)
        files_list.append(temp_file)

    # get table header
    header = ""
    with open(files_list[0]) as f:
        header = f.readline()

    # add header to partitions
    for file in files_list[1:]:
        with open(file, 'r') as original:
            data = original.read()
        with open(file, 'w') as modified:
            modified.write(header + data)

    for file in files_list:
        filenames.append(pd.read_csv(file,index_col=(0)))

    return filenames



    # format the file to include the partition number
    file = f'{file}.{extentsion}'


file = sys.argv[1]
partitions = int(sys.argv[2])


# global variables from website input
filenames = downloadPartitions(file, partitions)

select = sys.argv[5]

#single condition = Single
#range condition = Range
where = sys.argv[6]

feat = sys.argv[7]

#single condition
single_cd = sys.argv[8]
single_val = sys.argv[9]

#range inputs

# ≤ = greater than equal to
# < = greater than
lo_cd = sys.argv[11]
hi_cd = sys.argv[13]
lo_val = float(sys.argv[10])
hi_val = float(sys.argv[12])

#groupby and function
groupby = sys.argv[4]
atp = sys.argv[3]



if __name__ == '__main__':
    
    main()
